package com.hongxiang.kforthirtysix.util;

/**
 * Created by dllo on 16/5/20.
 */
public interface LolRvLinstener {

        void Onclick(int pos);

}

package com.hongxiang.kforthirtysix.util;

/**
 * Created by dllo on 16/5/14.
 */
public interface NewRvListener {
    void Onclick(int pos);
}

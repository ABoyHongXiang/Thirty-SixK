package com.hongxiang.kforthirtysix.bean;

import java.util.List;

/**
 * Created by dllo on 16/5/14.
 */
public class RecentBean {

    /**
     * code : 0
     * data : {"page":1,"totalCount":0,"data":[{"feedId":"5046968","title":"智能血压计3.0？无袖套指触式的暖心蛋还可同时监测心率","publishTime":1463143244000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/58e7e864-af5b-4317-9795-a8f9dd2bbc45/6.pic.jpg","commentCount":5,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/468024/106a448b-b7b0-49a5-9a77-97f30d509221.JPG!480","name":"su小吱","ssoId":468024}},{"feedId":"5046914","title":"从VR版密室逃脱开始，奥秘游戏同时布局内容开发和VR体验店","publishTime":1463133774000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/eb559794-8965-4956-8fb0-1eb3682156f9/_____20160513161909.png","commentCount":4,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/455899/f95be6cd-1c72-4c02-8683-b6a412279734.jpg!480","name":"Yuri","ssoId":455899}},{"feedId":"5046957","title":"\u201c二宝\u201d做着珠宝电商的买卖，还操了珠宝鉴定的那份心","publishTime":1463132804000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/7c6df3ec-8653-49ac-b586-d6fc0b5775ba/57.pic.jpg","commentCount":1,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201604/01112515/hw8bkcrlo89fx9we.jpg!480","name":"徐冰","ssoId":838090}},{"feedId":"5046965","title":"为你筛选出最棒的照片，The Roll是否将掀起\u201c手机相册革命\u201d？","publishTime":1463132674000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/024a9e97-fc2a-48a0-b017-96e73a7883a1/the_roll_social_media___.png","commentCount":4,"user":{"avatar":"https://pic.36krcnd.com/avatar/201605/03052519/sb8aqszymiq7udqm.jpg","name":"宇多田","ssoId":857389}},{"feedId":"5046941","title":"智能硬件+乐音识别，Poputar 让学吉他变成了一种游戏","publishTime":1463129290000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/713c2bbf-40d4-40df-a28c-f36c6afc33e3/__.jpg","commentCount":2,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/469680/7275d06b-2c78-4d34-afc7-ef5cd604d901.jpeg!480","name":"郭雨萌","ssoId":469680}},{"feedId":"5046958","title":"为消灭烦人的口头语，5名哈佛学生开发了一款叫 Ummo 的应用","publishTime":1463127517000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/36d22b3c-4cff-4b83-9ad2-c6905c568323/_____2016-05-13___4.06.18.png","commentCount":1,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/d72b67caf6eb9e2173e84bb38038404a!480","name":"张悦","ssoId":856322}},{"feedId":"5046956","title":"平行进口车电商平台\u201c优购汽车\u201d宣布获得A轮千万级融资，除汽车交付其他环节全部实现线上化","publishTime":1463119052000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/73da7973-5873-42a8-8c30-ab85d770f809/_____2016-05-13___1.56.47.png","commentCount":0,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/786/dbc783d3-6c9b-4e99-a42b-4884e412e99d.jpeg!480","name":"Nicholas","ssoId":786}},{"feedId":"5046952","title":"宣布进军无人驾驶，做千米测距测绘雷达出身的\u201c北科天绘\u201d做了一款16线避障型雷达","publishTime":1463111968000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/22812648-21ee-48a8-87c3-930806cdea6b/_____2016-05-13___11.55.27.png","commentCount":2,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/786/dbc783d3-6c9b-4e99-a42b-4884e412e99d.jpeg!480","name":"Nicholas","ssoId":786}},{"feedId":"5046948","title":"Accion Systems获750万美元A轮融资，研发航天用微型离子引擎","publishTime":1463108048000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/b57b8e33-bf3c-461d-a591-f198ba213000/_____20160513104857.png","commentCount":1,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/455899/f95be6cd-1c72-4c02-8683-b6a412279734.jpg!480","name":"Yuri","ssoId":455899}},{"feedId":"5046879","title":"UGC切入音乐生产端，\u201c作词\u201d像一个诗词版的朋友圈","publishTime":1463107831000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/28fc7855-4430-40e6-a969-9abcdc729501/_____2016-05-13_10.34.40.png","commentCount":0,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201512/18/5e67c1c24eb44acfbdcf58ae926fcdb9.jpg!480","name":"Mihawk","ssoId":331529}},{"feedId":"5046947","title":"面向小企业的网上借贷平台Capital Float获2500万美元B轮融资","publishTime":1463106980000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/40e089d3-bad1-44c2-be78-b0357b023fcf/_____2016-05-13___10.30.46.png","commentCount":1,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/2694/05f4a8a5-17c2-45c2-b171-e8f0dd3bfeb8.jpg!480","name":"达达","ssoId":2694}},{"feedId":"5046946","title":"香港券商 8 Securities 推出免佣港美股交易平台，同时提供中国版定制网站","publishTime":1463106924000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/2c6a80b1-8f96-4eed-9fd4-f304bf432fe7/___.png","commentCount":0,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/447411/2f14ff75-e1af-499e-b24b-dd66fcc2dbb7.jpg!480","name":"老扎","ssoId":447411}},{"feedId":"5046930","title":"得到亚马逊与保罗.艾伦鼎力支持，KITT.AI发布首个\u201c热词探测\u201d软件工具箱","publishTime":1463105318000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/86bb9492-af0a-4f68-9457-391a952f8a34/automatic-speech-recognition-mobile.jpg","commentCount":3,"user":{"avatar":"https://pic.36krcnd.com/avatar/201605/03052519/sb8aqszymiq7udqm.jpg","name":"宇多田","ssoId":857389}},{"feedId":"5046939","title":"主打 15 分钟轻咨询，成长保想解决 3 亿家庭的亲子教育问题","publishTime":1463103788000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/13cae16a-1de6-4d62-89e4-3e499710411c/2.pic.jpg","commentCount":5,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/469680/7275d06b-2c78-4d34-afc7-ef5cd604d901.jpeg!480","name":"郭雨萌","ssoId":469680}},{"feedId":"5046943","title":"去除中间环节，让本地旅行机构直接为游客提供定制旅行服务的Evaneos融资2100万美元","publishTime":1463100630000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/7b90e174-f887-4282-aced-6d7c197940c9/_____2016-05-13___8.44.42.png","commentCount":0,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/2694/05f4a8a5-17c2-45c2-b171-e8f0dd3bfeb8.jpg!480","name":"达达","ssoId":2694}},{"feedId":"5046907","title":"虚拟键盘除了打字还能做什么？Moment Keyboard 还能查个天气记个笔记","publishTime":1463051836000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/09fa5638-390e-4449-af52-6bfc09c09961/moment6.jpg","commentCount":7,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201603/28075404/c1n5irreqeci9fug.jpg!480","name":"农宝朱","ssoId":836721}},{"feedId":"5046927","title":"众包直送太贵？\u201c快速递\u201d通过与快递协作寻求同城配送平衡","publishTime":1463046210000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/5ce77104-b0ef-48f3-8fe9-4e6da33e32ff/___.PNG","commentCount":4,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/392679/6fb6e449-2795-4de8-8240-bfaa2becd9d1.jpg!480","name":"杜暮雨","ssoId":392679}},{"feedId":"5046817","title":"从美术外包到应用开发，萌布玩借VR转型寻求更大发展","publishTime":1463040029000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/fc70a958-f15b-4c31-a55f-93aacf14e019/_____20160512114955.png","commentCount":2,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/455899/f95be6cd-1c72-4c02-8683-b6a412279734.jpg!480","name":"Yuri","ssoId":455899}},{"feedId":"5046917","title":"主打特卖，医药B2B平台药便宜获投千万元级天使基金","publishTime":1463039040000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/4282f73b-9595-46c4-9f8a-34401c33fc4f/2.jpg","commentCount":6,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/468024/106a448b-b7b0-49a5-9a77-97f30d509221.JPG!480","name":"su小吱","ssoId":468024}},{"feedId":"5046905","title":"原\u201c土家西施\u201d土家掉渣饼创始人携\u201c又卷烧饼\u201d获1000万元天使轮融资，这次如何避免重蹈土家掉渣饼覆辙？","publishTime":1463038953000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/c8523d2c-75e4-4a25-9f18-731aa29bf595/26.pic.jpg","commentCount":8,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201601/12051420/2crs7xdj6mlvkhph.jpg!480","name":"惜墨","ssoId":591203}}],"pageSize":20,"totalPages":0}
     * msg : 操作成功！
     */

    private int code;
    /**
     * page : 1
     * totalCount : 0
     * data : [{"feedId":"5046968","title":"智能血压计3.0？无袖套指触式的暖心蛋还可同时监测心率","publishTime":1463143244000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/58e7e864-af5b-4317-9795-a8f9dd2bbc45/6.pic.jpg","commentCount":5,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/468024/106a448b-b7b0-49a5-9a77-97f30d509221.JPG!480","name":"su小吱","ssoId":468024}},{"feedId":"5046914","title":"从VR版密室逃脱开始，奥秘游戏同时布局内容开发和VR体验店","publishTime":1463133774000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/eb559794-8965-4956-8fb0-1eb3682156f9/_____20160513161909.png","commentCount":4,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/455899/f95be6cd-1c72-4c02-8683-b6a412279734.jpg!480","name":"Yuri","ssoId":455899}},{"feedId":"5046957","title":"\u201c二宝\u201d做着珠宝电商的买卖，还操了珠宝鉴定的那份心","publishTime":1463132804000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/7c6df3ec-8653-49ac-b586-d6fc0b5775ba/57.pic.jpg","commentCount":1,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201604/01112515/hw8bkcrlo89fx9we.jpg!480","name":"徐冰","ssoId":838090}},{"feedId":"5046965","title":"为你筛选出最棒的照片，The Roll是否将掀起\u201c手机相册革命\u201d？","publishTime":1463132674000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/024a9e97-fc2a-48a0-b017-96e73a7883a1/the_roll_social_media___.png","commentCount":4,"user":{"avatar":"https://pic.36krcnd.com/avatar/201605/03052519/sb8aqszymiq7udqm.jpg","name":"宇多田","ssoId":857389}},{"feedId":"5046941","title":"智能硬件+乐音识别，Poputar 让学吉他变成了一种游戏","publishTime":1463129290000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/713c2bbf-40d4-40df-a28c-f36c6afc33e3/__.jpg","commentCount":2,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/469680/7275d06b-2c78-4d34-afc7-ef5cd604d901.jpeg!480","name":"郭雨萌","ssoId":469680}},{"feedId":"5046958","title":"为消灭烦人的口头语，5名哈佛学生开发了一款叫 Ummo 的应用","publishTime":1463127517000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/36d22b3c-4cff-4b83-9ad2-c6905c568323/_____2016-05-13___4.06.18.png","commentCount":1,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/d72b67caf6eb9e2173e84bb38038404a!480","name":"张悦","ssoId":856322}},{"feedId":"5046956","title":"平行进口车电商平台\u201c优购汽车\u201d宣布获得A轮千万级融资，除汽车交付其他环节全部实现线上化","publishTime":1463119052000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/73da7973-5873-42a8-8c30-ab85d770f809/_____2016-05-13___1.56.47.png","commentCount":0,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/786/dbc783d3-6c9b-4e99-a42b-4884e412e99d.jpeg!480","name":"Nicholas","ssoId":786}},{"feedId":"5046952","title":"宣布进军无人驾驶，做千米测距测绘雷达出身的\u201c北科天绘\u201d做了一款16线避障型雷达","publishTime":1463111968000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/22812648-21ee-48a8-87c3-930806cdea6b/_____2016-05-13___11.55.27.png","commentCount":2,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/786/dbc783d3-6c9b-4e99-a42b-4884e412e99d.jpeg!480","name":"Nicholas","ssoId":786}},{"feedId":"5046948","title":"Accion Systems获750万美元A轮融资，研发航天用微型离子引擎","publishTime":1463108048000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/b57b8e33-bf3c-461d-a591-f198ba213000/_____20160513104857.png","commentCount":1,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/455899/f95be6cd-1c72-4c02-8683-b6a412279734.jpg!480","name":"Yuri","ssoId":455899}},{"feedId":"5046879","title":"UGC切入音乐生产端，\u201c作词\u201d像一个诗词版的朋友圈","publishTime":1463107831000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/28fc7855-4430-40e6-a969-9abcdc729501/_____2016-05-13_10.34.40.png","commentCount":0,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201512/18/5e67c1c24eb44acfbdcf58ae926fcdb9.jpg!480","name":"Mihawk","ssoId":331529}},{"feedId":"5046947","title":"面向小企业的网上借贷平台Capital Float获2500万美元B轮融资","publishTime":1463106980000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/40e089d3-bad1-44c2-be78-b0357b023fcf/_____2016-05-13___10.30.46.png","commentCount":1,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/2694/05f4a8a5-17c2-45c2-b171-e8f0dd3bfeb8.jpg!480","name":"达达","ssoId":2694}},{"feedId":"5046946","title":"香港券商 8 Securities 推出免佣港美股交易平台，同时提供中国版定制网站","publishTime":1463106924000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/2c6a80b1-8f96-4eed-9fd4-f304bf432fe7/___.png","commentCount":0,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/447411/2f14ff75-e1af-499e-b24b-dd66fcc2dbb7.jpg!480","name":"老扎","ssoId":447411}},{"feedId":"5046930","title":"得到亚马逊与保罗.艾伦鼎力支持，KITT.AI发布首个\u201c热词探测\u201d软件工具箱","publishTime":1463105318000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/86bb9492-af0a-4f68-9457-391a952f8a34/automatic-speech-recognition-mobile.jpg","commentCount":3,"user":{"avatar":"https://pic.36krcnd.com/avatar/201605/03052519/sb8aqszymiq7udqm.jpg","name":"宇多田","ssoId":857389}},{"feedId":"5046939","title":"主打 15 分钟轻咨询，成长保想解决 3 亿家庭的亲子教育问题","publishTime":1463103788000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/13cae16a-1de6-4d62-89e4-3e499710411c/2.pic.jpg","commentCount":5,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/469680/7275d06b-2c78-4d34-afc7-ef5cd604d901.jpeg!480","name":"郭雨萌","ssoId":469680}},{"feedId":"5046943","title":"去除中间环节，让本地旅行机构直接为游客提供定制旅行服务的Evaneos融资2100万美元","publishTime":1463100630000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/7b90e174-f887-4282-aced-6d7c197940c9/_____2016-05-13___8.44.42.png","commentCount":0,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/2694/05f4a8a5-17c2-45c2-b171-e8f0dd3bfeb8.jpg!480","name":"达达","ssoId":2694}},{"feedId":"5046907","title":"虚拟键盘除了打字还能做什么？Moment Keyboard 还能查个天气记个笔记","publishTime":1463051836000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/09fa5638-390e-4449-af52-6bfc09c09961/moment6.jpg","commentCount":7,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201603/28075404/c1n5irreqeci9fug.jpg!480","name":"农宝朱","ssoId":836721}},{"feedId":"5046927","title":"众包直送太贵？\u201c快速递\u201d通过与快递协作寻求同城配送平衡","publishTime":1463046210000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/5ce77104-b0ef-48f3-8fe9-4e6da33e32ff/___.PNG","commentCount":4,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/392679/6fb6e449-2795-4de8-8240-bfaa2becd9d1.jpg!480","name":"杜暮雨","ssoId":392679}},{"feedId":"5046817","title":"从美术外包到应用开发，萌布玩借VR转型寻求更大发展","publishTime":1463040029000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/fc70a958-f15b-4c31-a55f-93aacf14e019/_____20160512114955.png","commentCount":2,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/455899/f95be6cd-1c72-4c02-8683-b6a412279734.jpg!480","name":"Yuri","ssoId":455899}},{"feedId":"5046917","title":"主打特卖，医药B2B平台药便宜获投千万元级天使基金","publishTime":1463039040000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/4282f73b-9595-46c4-9f8a-34401c33fc4f/2.jpg","commentCount":6,"user":{"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/468024/106a448b-b7b0-49a5-9a77-97f30d509221.JPG!480","name":"su小吱","ssoId":468024}},{"feedId":"5046905","title":"原\u201c土家西施\u201d土家掉渣饼创始人携\u201c又卷烧饼\u201d获1000万元天使轮融资，这次如何避免重蹈土家掉渣饼覆辙？","publishTime":1463038953000,"columnName":"早期项目","columnId":"67","type":"article","featureImg":"http://a.36krcnd.com/nil_class/c8523d2c-75e4-4a25-9f18-731aa29bf595/26.pic.jpg","commentCount":8,"user":{"avatar":"https://krplus-pic.b0.upaiyun.com/201601/12051420/2crs7xdj6mlvkhph.jpg!480","name":"惜墨","ssoId":591203}}]
     * pageSize : 20
     * totalPages : 0
     */

    private DataBean data;
    private String msg;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public static class DataBean {
        private int page;
        private int totalCount;
        private int pageSize;
        private int totalPages;
        /**
         * feedId : 5046968
         * title : 智能血压计3.0？无袖套指触式的暖心蛋还可同时监测心率
         * publishTime : 1463143244000
         * columnName : 早期项目
         * columnId : 67
         * type : article
         * featureImg : http://a.36krcnd.com/nil_class/58e7e864-af5b-4317-9795-a8f9dd2bbc45/6.pic.jpg
         * commentCount : 5
         * user : {"avatar":"https://krid-assets.b0.upaiyun.com/uploads/user/avatar/468024/106a448b-b7b0-49a5-9a77-97f30d509221.JPG!480","name":"su小吱","ssoId":468024}
         */

        private List<DataBean1> data;

        public int getPage() {
            return page;
        }

        public void setPage(int page) {
            this.page = page;
        }

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getTotalPages() {
            return totalPages;
        }

        public void setTotalPages(int totalPages) {
            this.totalPages = totalPages;
        }

        public List<DataBean1> getData() {
            return data;
        }

        public void setData(List<DataBean1> data) {
            this.data = data;
        }

        public static class DataBean1 {
            private String feedId;
            private String title;
            private long publishTime;
            private String columnName;
            private String columnId;
            private String type;
            private String featureImg;
            private int commentCount;
            /**
             * avatar : https://krid-assets.b0.upaiyun.com/uploads/user/avatar/468024/106a448b-b7b0-49a5-9a77-97f30d509221.JPG!480
             * name : su小吱
             * ssoId : 468024
             */

            private UserBean user;

            public String getFeedId() {
                return feedId;
            }

            public void setFeedId(String feedId) {
                this.feedId = feedId;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public long getPublishTime() {
                return publishTime;
            }

            public void setPublishTime(long publishTime) {
                this.publishTime = publishTime;
            }

            public String getColumnName() {
                return columnName;
            }

            public void setColumnName(String columnName) {
                this.columnName = columnName;
            }

            public String getColumnId() {
                return columnId;
            }

            public void setColumnId(String columnId) {
                this.columnId = columnId;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getFeatureImg() {
                return featureImg;
            }

            public void setFeatureImg(String featureImg) {
                this.featureImg = featureImg;
            }

            public int getCommentCount() {
                return commentCount;
            }

            public void setCommentCount(int commentCount) {
                this.commentCount = commentCount;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public static class UserBean {
                private String avatar;
                private String name;
                private int ssoId;

                public String getAvatar() {
                    return avatar;
                }

                public void setAvatar(String avatar) {
                    this.avatar = avatar;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public int getSsoId() {
                    return ssoId;
                }

                public void setSsoId(int ssoId) {
                    this.ssoId = ssoId;
                }
            }
        }
    }
}
